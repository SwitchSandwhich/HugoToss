function PopUp(hideOrshow) {
  if (hideOrshow == 'hide') document.getElementById('ac-wrapper').style.display = "none";
  else document.getElementById('ac-wrapper').removeAttribute('style');
}
window.onload = function() {
  setTimeout(function() {
    PopUp('show');
  }, 1000);
}


document.addEventListener('DOMContentLoaded', function() {
  var div = document.getElementById('Great');
  if (div) { // Check if the div element exists
    window.addEventListener('scroll', function() {
      var scroll = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;
      div.style.background = `rgba(0, 0, 0, ${Math.max(0, Math.min(1, scroll / 200))})`;
    });
  }
});

// DOM utility functions:
{
const el = (sel, par) => (par || document).querySelector(sel);
const els = (sel, par) => (par || document).querySelectorAll(sel);
const elNew = (tag, prop) => Object.assign(document.createElement(tag), prop);

// Helper functions:

const mod = (n, m) => (n % m + m) % m;

// Task: Carousel:

const carousel = (elCarousel) => {

    const animation = 500;
    const pause = 3.5*1000;
    // Or use something like: const animation = Math.abs(elCarousel.dataset.carouselAnimation ?? 500);

    const elCarouselSlider = el(".carousel-slider", elCarousel);
    const elsSlides = els(".carousel-slide", elCarouselSlider);
    const elsBtns = [];

    let itv; // Autoslide interval
    let tot = elsSlides.length; // Total slides
    let c = 0;

    if (tot < 2) return; // Not enough slides. Do nothing.
    
      // Methods:
      const anim = (ms = animation) => {
        const cMod = mod(c, tot);
        // Move slider
        elCarouselSlider.style.transitionDuration = `${ms}ms`;
        elCarouselSlider.style.transform = `translateX(${(-c - 1) * 100}%)`;
        // Handle active classes (slide and bullet)
        elsSlides.forEach((elSlide, i) => elSlide.classList.toggle("is-active", cMod === i));
        elsBtns.forEach((elBtn, i) => elBtn.classList.toggle("is-active", cMod === i));
      };
    
      const prev = () => {
        if (c <= -1) return; // prevent blanks on fast prev-click
        c -= 1;
        anim();
      };
    
      const next = () => {
        if (c >= tot) return; // prevent blanks on fast next-click
        c += 1;
        anim();
      };
    
      const goto = (index) => {
        c = index;
        anim();
      };
      
      const play = () => {
        itv = setInterval(next, pause + animation);
        };
      
      const stop = () => {
        clearInterval(itv);
        };
        
        // Buttons:

  const elPrev = elNew("button", {
    type: "button",
    className: "carousel-prev",
    innerHTML: "<span><</span>",
    onclick: () => prev(),
  });

  const elNext = elNew("button", {
    type: "button",
    className: "carousel-next",
    innerHTML: "<span>></span>",
    onclick: () => next(),
  });
  
  // Navigation:

  const elNavigation = elNew("div", {
    className: "carousel-navigation",
  });

// Navigation bullets:

for (let i = 0; i < tot; i++) {
  const elBtn = elNew("button", {
    type: "button",
    className: "carousel-bullet",
    onclick: () => goto(i)
  });
  elsBtns.push(elBtn);
}


// Events:

// Infinite slide effect:
elCarouselSlider.addEventListener("transitionend", () => {
  if (c <= -1) c = tot - 1;
  if (c >= tot) c = 0;
  anim(0); // quickly switch to "c" slide (with animation duration 0)
});

// Pause on pointer enter:
elCarousel.addEventListener("pointerenter", () => stop());
elCarousel.addEventListener("pointerleave", () => play());

// Init:

// Insert UI elements:
elNavigation.append(...elsBtns);
elCarousel.append(elPrev, elNext, elNavigation);

// Clone first and last slides (for "infinite" slider effect)
elCarouselSlider.prepend(elsSlides[tot - 1].cloneNode(true));
elCarouselSlider.append(elsSlides[0].cloneNode(true));

// Initial slide
anim();

// Start autoplay
play();
};

// Allows to use multiple carousels on the same page:
els(".carousel").forEach(carousel);
}


{
const carousel= document.querySelector(".carousel-2"),
 firstImg = carousel.querySelectorAll(".carousel-2-slide")[0], 
arrowIcons = document.querySelectorAll(".wrapper i")


let isDragStart = false, isDragging = false, prevPageX, prevScrollLeft, positionDiff;


const showHideIcons = () => {
    const scrollWidth = carousel.scrollWidth - carousel.clientWidth;
    const scrollLeft = Math.round(carousel.scrollLeft);

    arrowIcons[0].style.display = scrollLeft === 0 ? "none" : "block";
    arrowIcons[1].style.display = scrollLeft >= scrollWidth - 1 ? "none" : "block";
};

arrowIcons.forEach(icon => {
    icon.addEventListener("click", () => {
        let firstImgWidth = firstImg.clientWidth + 14; // getting first img width & adding 14 margin value;
        // if clicked icon is left, reduce width value from the carousel scroll left else add to it
       carousel.scrollLeft += icon.id == "left" ? -firstImgWidth : firstImgWidth;
        setTimeout(() => showHideIcons(), 0); // calling showHideIcons after 60ms
    });
});
const autoSlide = () => {
    // if there is no image left to scroll then return from here
    if(carousel.scrollLeft - (carousel.scrollWidth - carousel.clientWidth) > -1 || carousel.scrollLeft <= 0) return;
    positionDiff = Math.abs(positionDiff); // making positionDiff value to positive
    let firstImgWidth = firstImg.clientWidth + 14;
    // getting difference value that needs to add or reduce from carousel left to take middle img center
    let valDifference = firstImgWidth - positionDiff;
    if(carousel.scrollLeft > prevScrollLeft) { // if user is scrolling to the right
        return carousel.scrollLeft += positionDiff > firstImgWidth / 3 ? valDifference : -positionDiff;
    }
    // if user is scrolling to the left
    carousel.scrollLeft -= positionDiff > firstImgWidth / 3 ? valDifference : -positionDiff;
}
const dragStart = (e) => {
    // updatating global variables value on mouse down event
    isDragStart = true;
    prevPageX = e.pageX || e.touches[0].pageX;
    prevScrollLeft = carousel.scrollLeft;
}
 const dragging = (e) => {
    // scrolling images/carousel to left according to mouse pointer
    if(!isDragStart) return;
    e.preventDefault();
    isDragging = true;
    carousel.classList.add("dragging");
    positionDiff = (e.pageX || e.touches[0].pageX) - prevPageX;
    carousel.scrollLeft = prevScrollLeft - positionDiff;
    showHideIcons();
}
const dragStop = () => {
    isDragStart = false;
    carousel.classList.remove("dragging");
if (!isDragging) return;
isDragging = false;
 carousel.scroll({
    left: carousel.scrollLeft,
    behavior: "smooth",
  });
 autoSlide(); 
}
carousel.addEventListener("mousedown", dragStart);
carousel.addEventListener("touchstart", dragStart);
document.addEventListener("mousemove", dragging);
carousel.addEventListener("touchmove", dragging);
document.addEventListener("mouseup", dragStop);
carousel.addEventListener("touchend",dragStop);
// Call showHideIcons initially
showHideIcons();

// Call showHideIcons on scroll event
carousel.addEventListener("scroll", showHideIcons);
}

//dropdown menu 
var dropdown = document.getElementsByClassName("dropdown-btn");
var i;

for (i = 0; i < dropdown.length; i++) {
  dropdown[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var dropdownContent = this.nextElementSibling;
    if (dropdownContent.style.display === "block") {
      dropdownContent.style.display = "none";
    } else {
      dropdownContent.style.display = "block";
    }
  });
}

//NavMenu 

/*function openNav() {
  document.getElementById("mySideNav").style.width = "45vw";
  document.getElementById("main").style.opacity = 0.5;
}

function closeNav() {
  document.getElementById("mySideNav").style.width = "0vw";
  document.getElementById("main").style.opacity = 1;
}

document.getElementById("openNavButton").addEventListener('click', function(event) {
  openNav(); // Call the openNav function
});

document.addEventListener('click', function(event) {
  var mySideNav = document.getElementById("mySideNav");
  var clickedElement = event.target;

  if (clickedElement.id !== "openNavButton" && !mySideNav.contains(clickedElement)) {
    closeNav(); // Close the mySideNav when clicked outside of it
  }
});
*/
//NavSideMenu with overlay, clickEvents.
function openNav() {
  document.getElementById("mySideNav").style.width = "45vw";
  document.getElementById("overlay").style.backgroundColor = "rgba(0, 0, 0, 0.6)";
  document.getElementById("overlay").style.pointerEvents = "auto";
}

function closeNav() {
  document.getElementById("mySideNav").style.width = "0vw";
  document.getElementById("overlay").style.backgroundColor = "transparent";
  document.getElementById("overlay").style.pointerEvents = "none";
}

document.getElementById("openNavButton").addEventListener('click', function(event) {
  event.preventDefault(); // Prevent default behavior of the button click
  openNav(); // Call the openNav function
});

document.addEventListener('click', function(event) {
  var mySideNav = document.getElementById("mySideNav");
  var clickedElement = event.target;

  if (clickedElement.id !== "openNavButton" && !mySideNav.contains(clickedElement)) {
    closeNav(); // Close the mySideNav when clicked outside of it
  }
});